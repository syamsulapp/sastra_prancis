<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Coba extends CI_Controller {

	function index() {
		$this->load->view('home');
	}
}
